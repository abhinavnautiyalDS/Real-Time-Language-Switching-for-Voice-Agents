# v4_3 -> v4_4
Rows: 761,574 -> 903,414  (train 723,240 / validation 90,066 / test 90,108).  Schema unchanged: text,label,category.

## 1. Backchannels / words a caller says while listening -> `none` (no switch)  (+15,783 rows)
yes, yeah, yaa, ok/okay, bye, thanks, hello, go-ahead / tell-me words (hi: हाँ, हाँ जी, जी हाँ, जी बोलिए, बोलिए, बताइए, ठीक है, अच्छा, नहीं जी ...;
roman: ha, haan, hanji, ji ha, boliye, boleye, bolo ...) and the same set in mr, bn, as, pa, gu, ta, te, kn, ml (native script + romanized) + 2-3 word combos
("haan ji boliye", "ok sir yes", "ji ha ji") + address terms (sir / madam / ji).
294 existing rows that were such words/nouns/interjections (e.g. hi-IN "हाँ जी", "जी बोलिए") relabelled to none -> changes/relabeled_to_none.csv

## 2. Case sensitivity (okay vs Okay vs OKAY)
Every Latin backchannel/greeting is present as lower, Capitalised and UPPER, each with plain / . / ! / ? endings, so "okay", "Okay", "OKAY", "ok", "OK", "Yes", "YES", "Bye" ... are all `none`.
Core words are forced into TRAIN (plain forms) - punctuated variants are spread over train/validation/test; rarer entries are held out by word for validation/test.

## 3. Class balance (target 75,000 per class)
Final: none 77,439, as-IN 75,975, gu-IN 75,000, pa-IN 75,000, bn-IN 75,000, ml-IN 75,000, te-IN 75,000, en-IN 75,000, hi-IN 75,000, mr-IN 75,000, kn-IN 75,000, ta-IN 75,000.
* Trimmed only redundant / templated rows: none -29,210 (Odia long sentences, names, numeric ids, entity pairs), hi-IN -4,959, as-IN -3,061 -> changes/trimmed_rows.csv
* Grown with NEW unique rows (no copies): 55% 4-9 word fragments of real rows + 45% STT-noise versions (stutters, fillers, dropped/swapped words, misspelt English, English words in native script).
  Each new row stays in the split of the row it came from (no leakage), is script-checked, and is de-duplicated against the whole dataset.
  Added: mr-IN +1,131, bn-IN +5,312, pa-IN +13,974, gu-IN +23,475, te-IN +23,623, ml-IN +23,637, ta-IN +23,651, kn-IN +23,663, en-IN +24,886 -> changes/augmented_rows.csv (categories <lang>_aug_fragment / <lang>_aug_noise)

## Checks done
* no identical text in two splits; no text with two different labels
* stand-in char-ngram model (case-sensitive): 40/40 backchannel tests -> none (incl. Okay/okay/OKAY, hanji, boleye, हाँ जी, बोलिए); 12/12 real sentences keep their language ("okay मुझे refund चाहिए" = hi-IN, "okay I want to cancel my order" = en-IN); balanced test acc 99.65%
## Notes
* "okay" alone = none, but "okay I want to cancel my order" = en-IN (there is a real sentence). Only whole-turn acknowledgements are none.
* none is 77k (largest by ~2k); if you still see it over-predicted, use class_weight 0.97 for none.
